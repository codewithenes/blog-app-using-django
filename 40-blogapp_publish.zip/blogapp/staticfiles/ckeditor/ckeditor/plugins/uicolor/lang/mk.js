﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","mk",{title:"Палета со бои",preview:"Преглед",config:"Залепи го овој текст во config.js датотеката",predefined:"Предефинирани множества на бои"});